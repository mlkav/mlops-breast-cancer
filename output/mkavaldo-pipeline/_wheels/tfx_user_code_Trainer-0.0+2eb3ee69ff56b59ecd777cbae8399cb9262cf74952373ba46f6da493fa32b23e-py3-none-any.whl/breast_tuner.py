
import os
import tensorflow_transform as tft
import tensorflow as tf
import keras_tuner as kt
from tfx.v1.components import TunerFnResult
from tfx.components.trainer.fn_args_utils import FnArgs
from breast_trainer import FEATURE_KEY, transformed_name, input_fn
from tensorflow.keras import layers
from tensorflow.keras.models import Model
from tensorflow.keras.callbacks import EarlyStopping, ModelCheckpoint

def model_builder(hyperparameters):
    input_features = []

    for key in FEATURE_KEY:
        input_features.append(
            tf.keras.Input(shape=(1,), name=transformed_name(key))
        )

    merged_input = layers.concatenate(input_features)

    # Hyperparameter untuk layer Dense dan Dropout
    units_1 = hyperparameters.Choice('units_1', [128, 256, 512])
    units_2 = hyperparameters.Choice('units_2', [64, 128, 256])
    units_3 = hyperparameters.Choice('units_3', [32, 64, 128])
    dropout_rate_1 = hyperparameters.Choice('dropout_rate_1', [0.2, 0.3, 0.4])
    dropout_rate_2 = hyperparameters.Choice('dropout_rate_2', [0.3, 0.4, 0.5])

    # Layer 1
    x = layers.Dense(units_1, activation='relu')(merged_input)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(dropout_rate_1)(x)

    # Layer 2
    x = layers.Dense(units_2, activation='relu')(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(dropout_rate_2)(x)

    # Layer 3
    x = layers.Dense(units_3, activation='relu')(x)
    x = layers.BatchNormalization()(x)
    x = layers.Dropout(dropout_rate_2)(x)

    # Output untuk klasifikasi biner
    outputs = layers.Dense(1, activation='sigmoid')(x)

    model = Model(inputs=input_features, outputs=outputs)

    model.compile(
      optimizer=tf.keras.optimizers.Adam(
      learning_rate=hyperparameters.Choice('learning_rate', [0.0001, 0.00005, 0.0005, 0.001])),
      loss='binary_crossentropy',
      metrics=['accuracy']
    )

    return model

def tuner_fn(fn_args: FnArgs):
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_graph_path)

    train_dataset = input_fn(fn_args.train_files, tf_transform_output, batch_size=64, num_epochs=1)
    eval_dataset = input_fn(fn_args.eval_files, tf_transform_output, batch_size=64, num_epochs=1)

    tuner = kt.RandomSearch(
        model_builder,
        objective='val_accuracy',
        max_trials=5,
        directory=fn_args.working_dir,
        project_name='kt_random_search'
    )

    # callbacks
    early_stopping = EarlyStopping(
        monitor='val_loss',
        patience=3,
        restore_best_weights=True
    )

    model_checkpoint = ModelCheckpoint(
        filepath=os.path.join(fn_args.working_dir, 'best_model.keras'),
        monitor='val_loss',
        save_best_only=True,
        mode='min'
    )

    return TunerFnResult(
        tuner=tuner,
        fit_kwargs={
            "x": train_dataset,
            'validation_data': eval_dataset,
            'steps_per_epoch': fn_args.train_steps,
            'validation_steps': fn_args.eval_steps,
            "epochs": 10,
            'callbacks': [early_stopping, model_checkpoint]
        }
    )
